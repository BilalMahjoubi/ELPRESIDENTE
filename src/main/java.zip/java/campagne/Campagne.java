package campagne;

import evenements.*;
import factions.Faction;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class Campagne {
    Faction[] factions;
    ArrayList<Evenement> evenements;
    private Faction capitalistes, communistes;
    private Economie economie;


    public Campagne() {
        factions = new Faction[]{
                new Faction("Communistes", 30, 60),
                new Faction("Capitalistes", 11, 90)};
        evenements = new ArrayList<>();
        economie = new Economie(1000, 100, 12, 12);
    }

    public void lancer(String difficlute) {
        int choix;
        Random r = new Random();
        int get;
        boolean echec = false;
        Scanner sc = new Scanner(System.in);
        Evenement e = new FemmeEvenement();
        Evenement c = new GuerreEvenement();
        evenements.add(e);
        evenements.add(c);
        EvenementFinAnnee fin = new EvenementFinAnnee();
        while (!echec) {
            for (int i = 0; i < 4; i++) {
                get = r.nextInt(evenements.size());
                evenements.get(get).toString();
                choix = sc.nextInt();
                if (difficlute.equals("n")) {
                    evenements.get(get).consequences(choix, economie, this);
                } else if (difficlute.equals("f")) {
                    evenements.get(get).consequencesFacile(choix, economie, this);

                }
            }
            fin.toString();
            choix = sc.nextInt();
            fin.consequences(choix, economie, this);
            echec = bilan(economie);

        }

    }


    public boolean bilan(Economie e) {
        int satisfaction_globale = 0;
        int nb_total = 0;
        int nourriture_total;
        for (Faction f : factions) {
            satisfaction_globale += f.satisfaction();
            nb_total += f.getNb_adherant();
        }
        satisfaction_globale /= nb_total;
        System.out.println(satisfaction_globale);
        nourriture_total = e.nourritureTotale(this);
        if (nourriture_total < 4) {
            e.elimination(this);
        }

        return satisfaction_globale < 50;
    }

    public Faction[] getFactions() {
        return factions;
    }

    public String choisirDifficulte() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Choisir un niveau de difficulté (f/n)");
        return sc.nextLine();
    }
}
