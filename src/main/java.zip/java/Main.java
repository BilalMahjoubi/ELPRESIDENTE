import campagne.Campagne;

public class Main {
    public static void main(String[] args) {
        Campagne c = new Campagne();
        String dif = c.choisirDifficulte();
        c.lancer(dif);

    }

}
